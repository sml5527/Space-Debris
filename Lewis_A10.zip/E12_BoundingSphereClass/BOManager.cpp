#include "BOManager.h"
BOManager* BOManager::instance = nullptr;

