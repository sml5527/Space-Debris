We believe that the models are colliding properly, but the HalfWidth properties seem to not be working correctly. 
One of them seems to be functioning on a different scale than the other one and we have not been able to remedy this problem. 
That being said all of the the collision code is in and seems to be accurate.